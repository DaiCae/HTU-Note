# HTU-Note

使用python flask框架作为后端的HTU Note 生成器

此项目仅用于个人学习
