class Config():
    def __init__(self):
        self.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Zyx20010616@sql.yuxuan.work:24748/HTU'
    